#!/bin/sh

docker build --tag 'quarkus-bug-54696' .
docker run --rm -it -v /var/run/docker.sock:/var/run/docker.sock quarkus-bug-54696
docker rmi quarkus-bug-54696:latest
